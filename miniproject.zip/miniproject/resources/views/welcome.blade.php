<!DOCTYPE html>
<html>
    <head>

        <title>Mini Project</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>


        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid.min.css" />
        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid-theme.min.css" />

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid.min.js"></script>


        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>


    <body>

    <h1>trial balance for jaya holdings</h1>

        <div class="container">
            <div class="content">
                <div id="jsGrid"></div>

            </div>



            <script>


                var clients = [
                    { "Year": 2015, "COA": 1012, "Description": "->Buildings", "Debit/Credit": "Debit", "Amount":900 },
                    { "Year": 2015, "COA": 1012, "Description": "->Buildings", "Debit/Credit": "Debit", "Amount":8989 },
                    { "Year": 2015, "COA": 1012, "Description": "->Buildings", "Debit/Credit": "Debit", "Amount":789 },
                    { "Year": 2015, "COA": 1012, "Description": "->Buildings", "Debit/Credit": "Debit", "Amount":909 },
                    { "Year": 2015, "COA": 1000, "Description": "->", "Debit/Credit": "Debit", "Amount":9000 },
                    { "Year": 2015, "COA": 1000, "Description": "assest->Buildings", "Debit/Credit": "Debit", "Amount":9000 },

                ];

                var payments = [
                    { Name: "", Id: 0 },
                    { Name: "Debit", Id: 1 },
                    { Name: "Credit", Id: 2 },

                ];

                $("#jsGrid").jsGrid({
                    width: "100%",
                    height: "400px",

                    inserting: true,
                    editing: true,
                    sorting: true,
                    paging: true,

                    data: clients,

                    fields: [
                        { name: "Year", type: "number", width: 150, validate: "required" },
                        { name: "COA", type: "number", width: 50 },
                        { name: "Description", type: "text", width: 200 },
                        { name: "Debit/Credit", type: "text", width:200 },
                        { name: "Amount", type: "number", title: "Amount", sorting: false },
                        { type: "control" }
                    ]
                });
            </script>


        </div>
    </body>
</html>
